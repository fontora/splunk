These are basic configuration bundles for a Splunk deployment.

Naming Convention

Customer Name _ Location of Configurations _ Splunk Instance _ Configuration Type

Example
Name:               acme_all_search_outputs
Description:        This configuration bundle will deployed at a customer named ACME to all search heads and contains the outputs.conf configuration file.

